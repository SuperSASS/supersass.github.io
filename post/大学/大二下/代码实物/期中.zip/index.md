---
title: 期中创客项目 - 多功能火灾警报器
description: 有关第20组期中创客项目的介绍。
date: 2022-04-28
lastmod: 
slug: univ-Code2Product-2
image: background.jpg
pixivID: 
yandereID: 
categories:
    - 大学相关
tags:
    - 大学课程
    - 从代码到实物
    - 项目记录
draft:
---

## 0x00 小组介绍

* 小组编号：第20组
* 小组成员
  * 刘云杰
  * 王翔
  * 蒋添爱
  * 郑然文
  * 王述杰

## 0x01 项目简介

### 1. 项目名称

{{< stress >}}
集温度、烟雾、火焰检测于一体的多功能火灾警报器
{{< /stress >}}

### 2. 项目背景

{{< note quote gray >}}

从第一次接触火元素，到学习理解掌握火的奥秘，人类就已经无法脱离火这种充盈着无尽能量的能源体，  
然而，火给生活带来了光明与希望，也给生活带来灰烬与灾难，  
从柔小火苗到冲天炽炎，往往只在顷刻间，人们或奔走哀嚎、或蜷缩哭泣，最终被这焰舌所吞噬，  
即便人们召唤它的本意，只是想让其带来些许温暖。

因此，人们依赖火、更敬畏火。  
从能检测周围火场并在即将灾难化自动鸣起警戒之声的火铃、到直接利用水元素与之正面对峙的自动灭火装置，  
人们从未忘记那一场场天罚般的业火，在心中所造成的创伤与疤痕。  
就算到如今人类已能熟练使用火系魔法，成为炎魔导师，火之大泛滥这一灵灾，仍时常袭于人们疏忽之瞬，  
待到红莲燃尽，万物归无，人们才会后悔悲痛于自己当时的那句“没什么”。

{{< /note >}}

为了纪念前人与火不断制衡对抗的艰苦历程，加强人们对火的警惕，  
我们组利用所学知识，并加上自己人性化的设计理念，  
最终创制出这杨一个“集温度、烟雾、火焰检测于一体”多功能火灾警报器，  
谨以此实物，纪念所有奋斗在消防事业的人们。

## 0x02 项目详细记录

### 1. 采用元件

* Arduino UNO ×1
* 温度传感器LM35模块 ×1
* 火焰传感器模块 ×1
* MQ2烟雾气体传感器模块 ×1
* 无源蜂鸣器模块 ×1
* LCD1602 ×1
* 5v电源扩展模块 ×1
* 椴木板 若干

![Arduino UNO接口示意图](pic/Arduino.png)

![元件清单 1](pic/Elements_1.png) ![元件清单 2](pic/Elements_2.png) ![元件清单 3](pic/Elements_3.png) ![元件清单 4](pic/Elements_4.png)

### 2. 采用技术

* 激光切割
* 硬件编程

### 3. 实现功能

* 综合烟雾检测
* 火焰检查（波长分析）
* 温度检测
* 火灾自动报警

### 4. 源代码

{{< snote link "原件使用例程 - [Gitee链接](https://gitee.com/SurvivorNo1/learninglogs_from_group_20/tree/1.0/fire_detection_code/units_Demos)" green >}}

{{< snote link "主程序源码 - [Gitee链接](https://gitee.com/SurvivorNo1/learninglogs_from_group_20/tree/1.0/fire_detection_code/units_Demos)" green >}}

## 0x03 项目时间线

{{< timeline theme="项目制作历程" >}}

{{< timeline/node time="2022-3-12" title="提出构想">}}
小组经过讨论，将焦点集中在生活上的一些常见问题，  
最终提出制作一个火灾警报器的构想。
{{< /timeline/node >}}

{{< timeline/node time="2022-3-24" title="外壳制作 - 激光切割">}}
由王翔同学负责设计警报器的外壳，  
利用CAD软件绘制激光切割路径后，前往工程训练中心利用木材进行激光切割，  
得到实物的外壳。
{{< /timeline/node >}}

{{< timeline/node time="2022-4-13" title="程序编写 - Arduino开发" >}}
由王述杰同学负责源码的编写调试，  
除显示屏模块外，利用他人的开源库，  
其余的温度、火焰、烟雾与报警模块均为自主编写。
{{< /timeline/node >}}

{{< timeline/node time="2020-4-22" title="实物组装">}}
由刘云杰同学负责开发板与外壳的组装拼接，  
将开发板与总线连接好后，固定在外壳内部，  
最终通过木板的铆接，完成封装。
{{< /timeline/node >}}

{{< timeline/node time="2020-4-28" title="项目总结与网页制作">}}
由郑然文同学负责总结本次开发项目，  
记录项目的开发背景与经过，形成文档。

然后由蒋添爱同学负责根据文档制作项目网页，  
并发布到博客上完成记录。
{{< /timeline/node >}}

{{< /timeline >}}

## 0x04 成品展示

![成品展示 1](pic/Product_1.jpg) ![成品展示 2](pic/Product_2.jpg)

{{< snote paperclip "[效果视频展示](pic/Product_3.mp4)" blue >}}
