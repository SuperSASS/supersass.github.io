#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

const int N=100000+10;

int n;
int h[N], a[N];

int main(){
	scanf("%d", &n); bool ans=true;
	for(int i=1; i<=n&&ans; ++i){
		scanf("%d", h+i);
		a[i]=h[i]-h[i-1];
		if(i>1 && a[i]>1) ans=false;
	}
	puts(ans?"Yes":"Do I have a chance?");
    return 0;
}

