#include<bits/stdc++.h>
using namespace std;
 
typedef long long LL;
 
const int N=100000;
 
int n,m,a[N+9],b[N+9];
 
LL ans;
 
void Get_ans(){
  ++n;a[n]=b[n]=m+1;
  for (int i=n;i>=1;--i) a[i]-=a[i-1]+1,b[i]-=b[i-1]+1;
  for (int i=1,j=1;i<=n;++i){
	if (!b[i]) continue;
	for (;!a[j];++j);
	int sum=0,l=j;
	for (;j<=n&&sum<b[i];++j) sum+=a[j];
	if (sum^b[i]) {ans=-1;return;}
	ans+=max(i-l,0)+max(j-1-i,0);
  }
}
 
int main(){
  scanf("%d%d",&n,&m);
  for (int i=1;i<=n;++i)
	scanf("%d",&a[i]);
  for (int i=1;i<=n;++i)
	scanf("%d",&b[i]);
  Get_ans();
  printf("%lld\n", ans);
  return 0;
}
