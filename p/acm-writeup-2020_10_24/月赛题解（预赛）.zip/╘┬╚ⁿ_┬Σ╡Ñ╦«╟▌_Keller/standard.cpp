#include <bits/stdc++.h>
using namespace std;
int main(){
	int T;cin>>T;
	while(T--){ 
		int n,ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			int x;scanf("%d",&x);
			ans^=x;
		}
		printf("%d\n",ans);
	}
	return 0;
}
