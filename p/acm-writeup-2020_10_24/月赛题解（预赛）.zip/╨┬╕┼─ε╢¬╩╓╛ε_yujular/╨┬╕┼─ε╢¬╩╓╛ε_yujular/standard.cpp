#include <iostream>

using namespace std;

int main()
{
    int T;
    cin>>T;
    while(T--){
        long long n;
        cin>>n;
        cout<<n<<endl;
    }
    return 0;
}

